#!/bin/bash

if [ $# -lt 1 ]; then
    echo "need program path filename"
    exit;
fi

path=$1
file=$2

if [ "$file" == "" ]; then
  file=srv-$(basename $path).tar.gz
fi

#echo "pack info:" $path $file
cd $path

echo "pack begin:"
echo -e "\e[1;31m   $path $file \e[0m "

echo "svn info:"
svn_info=`svn info ./src | grep "URL:"`
echo -e "\e[1;31m   $svn_info \e[0m "

echo "svn update:"
svn_up=`svn up ./src | awk '{print "    "$0}'`
echo -e "\e[1;31m$svn_up \e[0m "

#check version and file
svn_file="svn.version"
svn_old_version=`cat $svn_file`
svn_cur_version=`svn log --limit 1 ./src | grep '^r[0-9]\+' | awk '{print $1}'`

echo "svn version:"
echo -e "\e[1;31m   old:$svn_old_version new:$svn_cur_version \e[0m "
#echo $svn_old_version
#echo $svn_cur_version
if [ -f $file ] && [ "$svn_old_version" == "$svn_cur_version" ]; then
  info="donot need pack! remove $file to force pack!!"
  echo -e "pack result:"
  echo -e "\e[1;31m   $info \e[0m "
  exit;
fi

#compile and output to server
cd ./src

chmod +x ./buildcmake.sh
chmod +x ./compile-debug.sh
./compile-debug.sh server

cd ..

#pack:todo md5 to check diff
tar czvf $file ./server

#output version
echo $svn_cur_version > $svn_file

echo "pack finish:"
md5_info=`md5sum $file`
echo -e "\e[1;31m   version:$svn_cur_version md5:$md5_info \e[0m "

