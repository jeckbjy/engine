#!/bin/bash

if [ $# -ne 1 ]; then
    echo "need program path filename"
    exit;
fi

#enter the pack.sh dir
cd `echo ${0%/*}`

path=$1
path_name=`basename $path`

is_cfg=`echo $path | grep -c /zconfig/`
if [ $is_cfg == 1 ]; then
  file=cfg-${path_name}.tar.gz
  ./packcfg.sh $path $file 1>&2
else
  file=srv-${path_name}.tar.gz
  ./packprog.sh $path $file 1>&2
fi

echo $file

