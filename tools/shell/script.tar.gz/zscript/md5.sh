#!/bin/bash

if [ $# -ne 4 ]; then
    echo "md5.sh $addr $password $path $file"
    exit
fi

cd `dirname $0`;

addr=$1
pawd=$2
path=$3
file=$4

old_md5=`./ssh.exp $addr $pawd $path "md5sum $file" | grep md5sum -A 1 | grep -v md5sum | cut -d ' ' -f1`
echo $old_md5

