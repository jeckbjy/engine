#!/bin/bash

if [ $# -lt 1 ]; then
  echo "usage:packcfg.sh config-path (tar_file_name)"
  exit;
fi

path=$1
file=$2

if [ "$file" == "" ]; then
  file=cfg-$(basename $path).tar.gz
fi

#echo $path $name $file
cd $path

if [ -d ./server ]; then
  echo "has server dir"
  rm -rf ./server
fi

echo "pack begin:"
echo -e "\e[1;31m   $path $file \e[0m "

echo "svn info:"
svn_info=`svn info ./config | grep "URL:"`
echo -e "\e[1;31m   $svn_info \e[0m "

echo "svn update:"
svn_up=`svn up ./config | awk '{print "    "$0}'`
echo -e "\e[1;31m   $svn_up \e[0m "

# tar file
mkdir -p ./server/Config
\cp ./config/*.txt ./server/Config >> /dev/null
tar czf $file ./server
rm -rf ./server

echo "pack finish:"
md5_info=`md5sum $file`
echo -e "\e[1;31m   $md5_info \e[0m "

