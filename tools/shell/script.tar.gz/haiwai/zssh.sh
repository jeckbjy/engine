#!/bin/bash

if [ $# -lt 1 ]; then
    exit;
fi

name=$1
cmds=$2
mode=$3

if [ "$name" == "" ]; then
  echo "need server name"
  exit;
fi

eval `./zawk.sh $name dest_`

#log
now=`date`
if [ "$cmds" != "" ]; then
  echo "$now: exec $cmds to $name $dest_addr" >> zzlog-ssh
else
  echo "$now: login $name $dest_addr" >> zzlog-ssh
fi

../zscript/ssh.exp $jump__addr $jump__pawd $dest_addr $dest_pawd $dest_path "$cmds" "$mode"

