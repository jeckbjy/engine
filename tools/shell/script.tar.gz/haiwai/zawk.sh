#!/bin/bash

name=$1
prev=$2

password="warship!@#$"

eval `awk '{if($1=="'$name'") printf("group=%s;region=%s;addr1=%s;addr2=%s;pawd=%s;tz=%s;path=%s;",$2,$3,$4,$5,$6,$7,$8)}' host.cfg`

if [ "$pawd" == "none" ]; then
  pawd=$password
fi

if [ "$addr1" == "none" ]; then
  addr=$addr2
else
  addr=$addr1
fi

#check jump info
if [ "$tz" != "none" ]; then
  eval `awk '{if($1=="'$tz'") printf("jump__addr=%s;jump__pawd=%s;",$4,$6)}' host.cfg`
  #echo "aaa:$tz" "$jump__addr $jump__pawd"
else
  jump__addr=$addr
  jump__pawd=$pawd
fi

#echo "aaa:"  $jump__addr $jump__pawd

p=$prev
echo "${p}addr=$addr;${p}pawd='$pawd';${p}tz=$tz;${p}path=$path;${p}addr1=$addr1;${p}addr2=$addr2;jump__addr=$jump__addr;jump__pawd='$jump__pawd'"

