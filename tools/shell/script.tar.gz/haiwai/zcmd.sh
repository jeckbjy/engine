#!/bin/bash

cd `dirname $0`;

group=$1
mode=$2
async=$3
log_db="zzlog-db"
log_srv="zzlog-srv"

#parse options!!!
while getopts ":a" arg; do
  case $arg in
    a)
      echo "use async mode:"
      async=1
    ;;
    \?)
      echo "invalid options!"
    ;;
  esac
done

if [ "$async" == "" ]; then
  async=0
fi

if [ $# -lt 2 ]; then
    echo "zcmd.sh name mode"
    exit;
fi

echo "async:" $async

function exec_cmd(){
    name=$1
    mode=$2

    echo "exec:$name $mode"
    case $mode in
      "r")
        echo -e "\e[1;34m    run server: $name!! no copy!! \e[0m "
        #./zssh.sh $name "find ./region* -maxdepth 1 -name "r" -exec {} \;"
        ./zssh.sh $name "./r-all"
      ;;
      "rc")
        echo -e "\e[1;31m    copy and run server: $name \e[0m "
        ./zssh.sh $name "./run-all"
      ;;
      "k")
        echo -e "\e[1;34m    sotp server: $name \e[0m "
        ./zssh.sh $name "./stop-all"
      ;;
      "s")  
        ./zssh.sh $name "./s" | grep -E "gamed|worldd|watch" | tee -a $log_srv
      ;;
      "wr")
        echo -e "\e[1;34m    run world: $name\e[0m "
        ./zssh.sh $name "find . -name 'world' -exec bash {}/r \;"
      ;;
      "wk")
        echo -e "\e[1;34m    stop world: $name\e[0m "
        ./zssh.sh $name "find . -name 'world' -exec bash {}/k \;"
      ;;
      "ws")
        ./zssh.sh $name "find . -name 'world' -exec bash {}/s \;"
      ;;
      "ds")
        #db status
        ./zssh.sh $name "./s" | grep "ttserver" | tee -a $log_db
      ;;
      "t")
        ./zssh.sh $name "date"
      ;;
      "e")
        echo "test: $name $mode"
      ;;
      *)
        echo "none command[$mode]!!!"
      ;;
    esac
}

#clean up game
if [ $mode == "ds" ]; then
  cat /dev/null > $log_db
elif [ $mode == "s" ]; then
  cat /dev/null > $log_srv
fi

#str=`awk '{if($2=="'$group'") printf("%s,",$1)}' host.cfg`

str=""
group_arr=$(echo $group | tr "|" "\n")
#echo "aa:"$group_arr
for g in ${group_arr[@]}
do
  tmp=`awk '{if($2=="'$g'") printf("%s,",$1)}' host.cfg`
  echo "group:$g $tmp"
  str=${str}${tmp}
done

arr=$(echo $str | tr "," "\n")
for i in ${arr[@]}
do
  if [ $async == 1 ]; then
    {
      exec_cmd $i $mode
    }&
  else
    exec_cmd $i $mode
  fi
done

wait
