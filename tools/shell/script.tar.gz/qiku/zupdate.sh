#!/bin/bash

if [ $# -lt 2 ]; then
  echo "usage:update group path_dir (jump_name)"
  exit
fi 

group=$1
path=$2
jump=$3

if [ "$jump" == "" ]; then
  jump="jump"
fi

if [ ! -d $path ]; then
  echo "path do not exits $path"
  exit;
fi

now=`date`
echo "$now:update $path $jump" >> zzlog-update

#parse jump
eval `./zawk.sh $jump jump_`


#pack 
step1="STEP 1:pack"
echo -e ""
echo -e "\e[1;34m${step1}\e[0m "
file=`../zscript/pack.sh $path`
file_path=$path/$file


#check md5 for update
step2="STEP 2:upload if md5 diff "
echo -e ""
echo -e ""
echo -e "\e[1;34m${step2}\e[0m "

cur_md5=`md5sum $file_path | cut -d " " -f1`
old_md5=`./zssh.sh $jump "md5sum $file" | grep md5sum -A 1 | grep -v md5sum | cut -d ' ' -f1`

echo -e "\e[1;31m    md5 info: $cur_md5 $old_md5 \e[0m "

if [ "$cur_md5" != "$old_md5" ]; then
  echo -e "\e[1;31m    head:  jump_addr  \t  dest_addr \t  dest_path \t  file_path \e[0m "
  echo -e "\e[1;31m    info: $jump__addr \t $jump_addr \t $jump_path \t $file_path \e[0m "

  ../zscript/upload-rsa.exp $jump__addr $jump__user $jump_addr $jump_user $jump_path $file_path

  old_md5=`./zssh.sh $jump "md5sum $file" | grep md5sum -A 1 | grep -v md5sum | cut -d ' ' -f1` 
  if [ "$cur_md5" != "$old_md5" ]; then
    echo -e "\e[1;31m    md5 info: $cur_md5 $old_md5 \e[0m "
    echo -e "\e[1;31m  upload result: fail!!!! fail!!!! please check \e[0m"
    exit
  else
    echo -e "\e[1;31m  upload result: success!!!!\e[0m"
  fi
else
  echo -e "\e[1;31m  upload result: success!!!! same md5,do not need upload!!\e[0m"
fi

#exit


#update file
step3="STEP 3: update file to all server group!!"
echo ""
echo ""
echo -e "\e[1;34m${step3}\e[0m "

#str=`awk '{if($2=="'$group'") printf("%s,",$1)}' host.cfg`
#str=`awk '$2 ~ /'$group'/ {printf("%s,",$1)}' host.cfg`

str=""
group_arr=$(echo $group | tr "|" "\n")
for g in ${group_arr[@]}
do
  tmp=`awk '{if($2=="'$g'") printf("%s,",$1)}' host.cfg`
  #echo "group:$g $tmp"
  str=${str}${tmp}
done

arr=$(echo $str | tr "," "\n")
for i in ${arr[@]}
do
  eval `./zawk.sh $i dest_`

  echo -e "\e[1;31m     update to server $i: $dest_addr2 $dest_path $file \e[0m "
  echo ""

  #echo $jump_addr $jump_user $jump_path $dest_addr2 $dest_user $dest_path $file
  ../zscript/update-rsa.exp $jump_addr $jump_user $jump_path $dest_addr2 $dest_user $dest_path $file | awk '{print "    "$0'}
done
